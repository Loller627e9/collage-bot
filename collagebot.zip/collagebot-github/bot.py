"""
bot.py — PGXC Collage Bot (production)

Config is loaded from .env (rename _env to .env).
Never hard-code BOT_TOKEN or ADMIN_IDS here.
"""

import os, asyncio, logging, time, json
from functools import wraps
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, BotCommand
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters
from telegram.request import HTTPXRequest
from collage import make_collage

# ── load .env -----------------------------------------------------------------
try:
    from dotenv import load_dotenv
    load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), ".env"), override=False)
except ImportError:
    pass  # rely on shell environment if python-dotenv is not installed

logging.basicConfig(format="%(asctime)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

# ── config (no fallback values — must be set in .env or environment) ----------
BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
ADMIN_IDS = set(int(x) for x in os.environ.get("ADMIN_IDS", "").split(",") if x.strip())

MAX_IMAGES     = 20
MAX_CONCURRENT = 20
AUTO_IDLE      = 2   # seconds of inactivity before auto-build fires
BATCH_IDLE     = 10  # seconds of inactivity before batch auto-builds

_job_sem: asyncio.Semaphore = None

# ── persistent state ----------------------------------------------------------
STATE_FILE = "bot_state.json"

def _load_state():
    try:
        with open(STATE_FILE) as f:
            d = json.load(f)
            return set(d.get("banned", [])), d.get("welcome", None)
    except Exception:
        return set(), None

def _save_state(banned: set, welcome: str):
    with open(STATE_FILE, "w") as f:
        json.dump({"banned": list(banned), "welcome": welcome}, f)

banned_users, _welcome_msg = _load_state()

DEFAULT_WELCOME = (
    "*Welcome to PGXC Collage Bot!*\n\n"
    "Turn your screenshots into clean, professional collages in seconds.\n\n"
    "────────────────\n"
    "*How to use:*\n"
    "Just send your screenshots — the bot builds automatically after 2 seconds.\n"
    "Use /batch to queue them all first, then it auto-builds after 10 seconds of silence.\n\n"
    "*Commands:*\n"
    "/batch — queue mode (auto-builds after 10 s of inactivity)\n"
    "/layout — choose grid style\n"
    "/quality — set JPEG quality (1–95)\n"
    "/watermark — add/remove a text tag\n"
    "/cropui — toggle removal of phone status/nav bars\n"
    "/enhance — toggle sharpness and colour boost\n"
    "/undo — remove last queued image\n"
    "/remove — remove image by position number\n"
    "/count — how many images are queued\n"
    "/status — current settings\n"
    "/clear — reset queue and settings\n"
    "────────────────\n"
    "Supports up to *20 images* per collage.\n"
    "Delivered as a full-quality document file.\n\n"
    "For help contact @PGXC_ADMIN"
)

def get_welcome():
    return _welcome_msg if _welcome_msg else DEFAULT_WELCOME

# ── sessions ------------------------------------------------------------------
sessions: dict = {}

def get_session(cid):
    if cid not in sessions:
        sessions[cid] = {
            "photos": [], "layout": "auto", "batch_mode": False,
            "last_photo_time": 0.0, "watermark": None, "quality": 92,
            "crop_ui": False, "enhance": False,
            "_auto_task": None, "_batch_task": None,
        }
    return sessions[cid]

def cancel(s, key):
    t = s.get(key)
    if t and not t.done():
        t.cancel()
    s[key] = None

def reset(cid):
    s = get_session(cid)
    s["photos"] = []
    s["batch_mode"] = False
    s["last_photo_time"] = 0.0
    cancel(s, "_auto_task")
    cancel(s, "_batch_task")

# ── auto-build (fires 2 s after last photo in normal mode) --------------------
async def _auto_worker(cid, context):
    await asyncio.sleep(AUTO_IDLE)
    s = get_session(cid)
    if time.time() - s["last_photo_time"] < AUTO_IDLE or s["batch_mode"]:
        return
    photos = list(s["photos"])
    if len(photos) < 2:
        return
    s["_auto_task"] = None
    await _build(cid, context, s, photos)

def schedule_auto(cid, context):
    s = get_session(cid)
    if s["batch_mode"]:
        return
    cancel(s, "_auto_task")
    s["_auto_task"] = asyncio.create_task(_auto_worker(cid, context))

# ── batch auto-build (fires 10 s after last photo in batch mode) --------------
async def _batch_worker(cid, context):
    await asyncio.sleep(BATCH_IDLE)
    s = get_session(cid)
    if not s["batch_mode"] or time.time() - s["last_photo_time"] < BATCH_IDLE:
        return
    s["batch_mode"] = False
    s["_batch_task"] = None
    photos = list(s["photos"])
    if len(photos) >= 2:
        await _build(cid, context, s, photos)

def schedule_batch_close(cid, context):
    s = get_session(cid)
    cancel(s, "_batch_task")
    s["_batch_task"] = asyncio.create_task(_batch_worker(cid, context))

# ── inline keyboard shown with every finished collage ------------------------
def edit_kb():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("Horizontal", callback_data="edit_hstrip"),
            InlineKeyboardButton("Wide",       callback_data="edit_wide"),
            InlineKeyboardButton("Vertical",   callback_data="edit_vstrip"),
        ],
        [
            InlineKeyboardButton("Compress",   callback_data="edit_compress"),
            InlineKeyboardButton("Watermark",  callback_data="edit_watermark"),
        ],
        [
            InlineKeyboardButton("Crop UI",    callback_data="edit_cropui"),
            InlineKeyboardButton("Enhance",    callback_data="edit_enhance"),
        ],
    ])

# ── core build ----------------------------------------------------------------
async def _build(cid, context, s, photos, layout=None, quality=None,
                 watermark=None, crop_ui=None, enhance=None, suffix=""):
    layout    = layout    if layout    is not None else s["layout"]
    quality   = quality   if quality   is not None else s["quality"]
    watermark = watermark if watermark is not None else s["watermark"]
    crop_ui   = crop_ui   if crop_ui   is not None else s["crop_ui"]
    enhance   = enhance   if enhance   is not None else s["enhance"]

    async with _job_sem:
        status = await context.bot.send_message(cid, "Building collage...")
        deleted = False
        img_paths = []
        output_path = f"/tmp/col_out_{cid}.jpg"
        try:
            for i, (_, fid) in enumerate(photos):
                f = await context.bot.get_file(fid)
                p = f"/tmp/col_{cid}_{i}.jpg"
                await f.download_to_drive(p)
                img_paths.append(p)

            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, lambda: make_collage(
                img_paths, output_path, layout=layout, quality=quality,
                watermark=watermark, enhance=enhance, crop_ui=crop_ui
            ))

            try: await status.delete()
            except Exception: pass
            deleted = True

            with open(output_path, "rb") as f:
                await context.bot.send_document(
                    cid, document=f, filename="PGXC_Collage.jpg",
                    caption=f"{len(photos)} images  |  {layout}{suffix}",
                    reply_markup=edit_kb(),
                    write_timeout=180, read_timeout=60, connect_timeout=10,
                )
            return True
        except Exception as e:
            logger.error(f"Build error {cid}: {e}", exc_info=True)
            try:
                if not deleted: await status.edit_text(f"Error: {e}")
                else: await context.bot.send_message(cid, f"Error: {e}")
            except Exception: pass
            return False
        finally:
            for p in img_paths:
                try: os.remove(p)
                except: pass
            try: os.remove(output_path)
            except: pass

# ── decorators ----------------------------------------------------------------
def require_not_banned(fn):
    @wraps(fn)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        uid = update.effective_user.id if update.effective_user else None
        if uid in banned_users:
            return
        return await fn(update, context)
    return wrapper

def require_admin(fn):
    @wraps(fn)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        uid = update.effective_user.id if update.effective_user else None
        if uid not in ADMIN_IDS:
            await update.message.reply_text("Admin only.")
            return
        return await fn(update, context)
    return wrapper

def is_admin(update: Update) -> bool:
    uid = update.effective_user.id if update.effective_user else None
    return uid in ADMIN_IDS

# ── photo ingestion -----------------------------------------------------------
async def _ingest(cid, context, kind, fid):
    s = get_session(cid)
    if len(s["photos"]) >= MAX_IMAGES:
        return
    s["photos"].append((kind, fid))
    s["last_photo_time"] = time.time()
    if s["batch_mode"]:
        schedule_batch_close(cid, context)
    else:
        schedule_auto(cid, context)

@require_not_banned
async def receive_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _ingest(update.effective_chat.id, context, "photo", update.message.photo[-1].file_id)

@require_not_banned
async def receive_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    doc = update.message.document
    if doc and doc.mime_type and doc.mime_type.startswith("image/"):
        await _ingest(update.effective_chat.id, context, "doc", doc.file_id)

# ── user commands -------------------------------------------------------------
ADMIN_HELP = (
    "*Admin Panel — PGXC Collage Bot*\n\n"
    "────────────────\n"
    "*User management:*\n"
    "/ban `<id>` — ban a user (or reply to their message)\n"
    "/unban `<id>` — unban a user\n"
    "/banlist — list all banned users\n\n"
    "*Broadcast:*\n"
    "/broadcast `<message>` — send a message to all active sessions\n\n"
    "*Welcome message:*\n"
    "/setwelcome `<text>` — set a custom welcome message\n"
    "/resetwelcome — restore the default welcome message\n\n"
    "*Stats:*\n"
    "/stats — total sessions, active queues, banned count\n\n"
    "────────────────\n"
    "Tip: reply to any user message and use /ban or /unban without an ID."
)

@require_not_banned
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(get_welcome(), parse_mode="Markdown")
    if is_admin(update):
        await update.message.reply_text(ADMIN_HELP, parse_mode="Markdown")

@require_admin
async def adminhelp_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(ADMIN_HELP, parse_mode="Markdown")

@require_not_banned
async def batch_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cid = update.effective_chat.id
    s = get_session(cid)
    cancel(s, "_auto_task")
    s["batch_mode"] = True
    s["last_photo_time"] = time.time()
    await update.message.reply_text(
        "Batch mode on. Send all your images — the collage builds automatically after 10 seconds of inactivity.",
        parse_mode="Markdown"
    )

@require_not_banned
async def layout_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Choose layout:", reply_markup=InlineKeyboardMarkup([
        [InlineKeyboardButton("Auto",       callback_data="layout_auto"),
         InlineKeyboardButton("Horizontal", callback_data="layout_hstrip")],
        [InlineKeyboardButton("Wide",       callback_data="layout_wide"),
         InlineKeyboardButton("Vertical",   callback_data="layout_vstrip")],
    ]))

@require_not_banned
async def quality_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    s = get_session(update.effective_chat.id)
    if not context.args:
        await update.message.reply_text(f"Current quality: *{s['quality']}*\nUsage: /quality `1-95`", parse_mode="Markdown")
        return
    try:
        q = int(context.args[0])
        assert 1 <= q <= 95
        s["quality"] = q
        await update.message.reply_text(f"Quality set to *{q}*.", parse_mode="Markdown")
    except Exception:
        await update.message.reply_text("Please enter a number between 1 and 95.")

@require_not_banned
async def watermark_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    s = get_session(update.effective_chat.id)
    text = " ".join(context.args).strip() if context.args else ""
    if not text:
        if s["watermark"]:
            s["watermark"] = None
            await update.message.reply_text("Watermark cleared.")
        else:
            await update.message.reply_text("Usage: /watermark `text`", parse_mode="Markdown")
        return
    s["watermark"] = text
    await update.message.reply_text(f"Watermark set to `{text}`.", parse_mode="Markdown")

@require_not_banned
async def cropui_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    s = get_session(update.effective_chat.id)
    s["crop_ui"] = not s["crop_ui"]
    state = "on" if s["crop_ui"] else "off"
    await update.message.reply_text(f"Crop UI is now *{state}*.", parse_mode="Markdown")

@require_not_banned
async def enhance_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    s = get_session(update.effective_chat.id)
    s["enhance"] = not s["enhance"]
    state = "on" if s["enhance"] else "off"
    await update.message.reply_text(f"Enhance is now *{state}*.", parse_mode="Markdown")

@require_not_banned
async def undo_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    s = get_session(update.effective_chat.id)
    if not s["photos"]:
        await update.message.reply_text("Queue is empty.")
        return
    s["photos"].pop()
    await update.message.reply_text(f"Last image removed. {len(s['photos'])} remaining.")

@require_not_banned
async def remove_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    s = get_session(update.effective_chat.id)
    n = len(s["photos"])
    try:
        idx = int(context.args[0]) - 1
        assert 0 <= idx < n
        s["photos"].pop(idx)
        await update.message.reply_text(f"Image #{idx+1} removed. {len(s['photos'])} remaining.")
    except Exception:
        await update.message.reply_text(f"Usage: /remove `<1-{n}>`", parse_mode="Markdown")

@require_not_banned
async def count_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    s = get_session(update.effective_chat.id)
    await update.message.reply_text(f"{len(s['photos'])} images queued.")

@require_not_banned
async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    s = get_session(update.effective_chat.id)
    wm = f"`{s['watermark']}`" if s["watermark"] else "none"
    await update.message.reply_text(
        f"*Current settings*\n\n"
        f"Queued: *{len(s['photos'])}*\n"
        f"Layout: *{s['layout']}*\n"
        f"Quality: *{s['quality']}*\n"
        f"Watermark: {wm}\n"
        f"Crop UI: *{'on' if s['crop_ui'] else 'off'}*\n"
        f"Enhance: *{'on' if s['enhance'] else 'off'}*\n"
        f"Batch mode: *{'on' if s['batch_mode'] else 'off'}*",
        parse_mode="Markdown"
    )

@require_not_banned
async def clear_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reset(update.effective_chat.id)
    await update.message.reply_text("Queue cleared.")

# ── admin commands ------------------------------------------------------------
def _resolve_target(update, context):
    if context.args:
        try:
            return int(context.args[0])
        except ValueError:
            return None
    if update.message.reply_to_message:
        return update.message.reply_to_message.from_user.id
    return None

@require_admin
async def ban_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global banned_users
    target = _resolve_target(update, context)
    if not target:
        await update.message.reply_text("Usage: /ban <user_id> or reply to a message.")
        return
    if target in ADMIN_IDS:
        await update.message.reply_text("Cannot ban an admin.")
        return
    banned_users.add(target)
    _save_state(banned_users, _welcome_msg)
    reset(target)
    await update.message.reply_text(f"User `{target}` banned.", parse_mode="Markdown")

@require_admin
async def unban_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global banned_users
    target = _resolve_target(update, context)
    if not target:
        await update.message.reply_text("Usage: /unban <user_id> or reply to a message.")
        return
    banned_users.discard(target)
    _save_state(banned_users, _welcome_msg)
    await update.message.reply_text(f"User `{target}` unbanned.", parse_mode="Markdown")

@require_admin
async def banlist_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not banned_users:
        await update.message.reply_text("No banned users.")
        return
    lines = "\n".join(f"- `{uid}`" for uid in sorted(banned_users))
    await update.message.reply_text(f"*Banned users:*\n{lines}", parse_mode="Markdown")

@require_admin
async def setwelcome_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global _welcome_msg
    if update.message.reply_to_message and update.message.reply_to_message.text:
        text = update.message.reply_to_message.text
    else:
        text = " ".join(context.args).strip() if context.args else ""
    if not text:
        await update.message.reply_text(
            "Usage: /setwelcome <text>  or reply to any message with /setwelcome\n"
            "Use /resetwelcome to restore the default."
        )
        return
    _welcome_msg = text
    _save_state(banned_users, _welcome_msg)
    await update.message.reply_text("Welcome message updated. Preview:")
    try:
        await update.message.reply_text(_welcome_msg, parse_mode="Markdown")
    except Exception:
        await update.message.reply_text(_welcome_msg)

@require_admin
async def resetwelcome_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global _welcome_msg
    _welcome_msg = None
    _save_state(banned_users, _welcome_msg)
    await update.message.reply_text("Welcome message reset to default.")

@require_admin
async def broadcast_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = " ".join(context.args).strip() if context.args else ""
    if not text:
        await update.message.reply_text("Usage: /broadcast <message>")
        return
    sent, failed = 0, 0
    for cid in list(sessions.keys()):
        try:
            await context.bot.send_message(cid, text, parse_mode="Markdown")
            sent += 1
        except Exception:
            failed += 1
    await update.message.reply_text(f"Sent: {sent}  |  Failed: {failed}")

@require_admin
async def stats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    total = len(sessions)
    active = sum(1 for s in sessions.values() if s["photos"])
    await update.message.reply_text(
        f"*Bot stats*\n\n"
        f"Total sessions: *{total}*\n"
        f"Active queues: *{active}*\n"
        f"Banned users: *{len(banned_users)}*",
        parse_mode="Markdown"
    )

# ── callbacks -----------------------------------------------------------------
async def layout_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    s = get_session(q.message.chat_id)
    s["layout"] = q.data.split("_", 1)[1]
    names = {"auto": "Auto", "hstrip": "Horizontal", "wide": "Wide", "vstrip": "Vertical"}
    await q.edit_message_text(f"Layout set to *{names[s['layout']]}*.", parse_mode="Markdown")

async def edit_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    cid = q.message.chat_id
    uid = q.from_user.id if q.from_user else None
    if uid in banned_users:
        return
    s = get_session(cid)
    action = q.data[5:]
    photos = s.get("photos", [])
    if len(photos) < 2:
        await q.answer("No images in session.", show_alert=True)
        return
    lnames = {"hstrip": "Horizontal", "wide": "Wide", "vstrip": "Vertical"}
    kw = {}
    if action in lnames:
        kw = {"layout": action, "suffix": f"  |  {lnames[action]}"}
    elif action == "compress":
        kw = {"quality": 60, "suffix": "  |  compressed"}
    elif action == "watermark":
        user = q.from_user
        if s.get("watermark"):
            wm_text = s["watermark"]
        elif user and user.username:
            wm_text = f"@{user.username}"
        elif user and user.first_name:
            wm_text = user.first_name
        else:
            wm_text = "TCT Collage Bot"
        kw = {"watermark": wm_text, "suffix": "  |  watermarked"}
    elif action == "cropui":
        kw = {"crop_ui": True, "suffix": "  |  UI cropped"}
    elif action == "enhance":
        kw = {"enhance": True, "suffix": "  |  enhanced"}
    else:
        return
    await _build(cid, context, s, photos, **kw)

# ── startup -------------------------------------------------------------------
async def post_init(app):
    global _job_sem
    _job_sem = asyncio.Semaphore(MAX_CONCURRENT)

    from telegram import BotCommandScopeChat, BotCommandScopeDefault

    user_cmds = [
        BotCommand("start",     "Welcome message"),
        BotCommand("batch",     "Queue mode — auto-builds after 10 s of inactivity"),
        BotCommand("layout",    "Choose collage grid style"),
        BotCommand("quality",   "Set JPEG quality (1–95)"),
        BotCommand("watermark", "Set or clear watermark text"),
        BotCommand("cropui",    "Toggle removal of phone status/nav bars"),
        BotCommand("enhance",   "Toggle sharpness and colour boost"),
        BotCommand("undo",      "Remove last queued image"),
        BotCommand("remove",    "Remove image by position number"),
        BotCommand("count",     "How many images are queued"),
        BotCommand("status",    "Show current settings"),
        BotCommand("clear",     "Reset queue and settings"),
    ]

    admin_cmds = user_cmds + [
        BotCommand("adminhelp",    "Admin panel"),
        BotCommand("ban",          "Ban a user"),
        BotCommand("unban",        "Unban a user"),
        BotCommand("banlist",      "List banned users"),
        BotCommand("broadcast",    "Broadcast a message"),
        BotCommand("setwelcome",   "Set custom welcome message"),
        BotCommand("resetwelcome", "Restore default welcome message"),
        BotCommand("stats",        "Bot stats"),
    ]

    # default for all users
    await app.bot.set_my_commands(user_cmds, scope=BotCommandScopeDefault())

    # override per admin chat so they see the full list
    for admin_id in ADMIN_IDS:
        try:
            await app.bot.set_my_commands(admin_cmds, scope=BotCommandScopeChat(chat_id=admin_id))
        except Exception as e:
            logger.warning("Could not set admin commands for %s: %s", admin_id, e)

def main():
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN is not set. Add it to your .env file.")
    if not ADMIN_IDS:
        logger.warning("ADMIN_IDS is not set — no admin commands will work.")

    request = HTTPXRequest(
        connect_timeout=10, read_timeout=60,
        write_timeout=180, pool_timeout=30,
        http_version="1.1",
    )
    app = (
        Application.builder()
        .token(BOT_TOKEN)
        .request(request)
        .post_init(post_init)
        .build()
    )

    # user
    app.add_handler(CommandHandler("start",     start))
    app.add_handler(CommandHandler("batch",     batch_cmd))
    app.add_handler(CommandHandler("layout",    layout_cmd))
    app.add_handler(CommandHandler("quality",   quality_cmd))
    app.add_handler(CommandHandler("watermark", watermark_cmd))
    app.add_handler(CommandHandler("cropui",    cropui_cmd))
    app.add_handler(CommandHandler("enhance",   enhance_cmd))
    app.add_handler(CommandHandler("undo",      undo_cmd))
    app.add_handler(CommandHandler("remove",    remove_cmd))
    app.add_handler(CommandHandler("count",     count_cmd))
    app.add_handler(CommandHandler("status",    status_cmd))
    app.add_handler(CommandHandler("clear",     clear_cmd))
    # admin
    app.add_handler(CommandHandler("adminhelp",    adminhelp_cmd))
    app.add_handler(CommandHandler("ban",          ban_cmd))
    app.add_handler(CommandHandler("unban",        unban_cmd))
    app.add_handler(CommandHandler("banlist",      banlist_cmd))
    app.add_handler(CommandHandler("setwelcome",   setwelcome_cmd))
    app.add_handler(CommandHandler("resetwelcome", resetwelcome_cmd))
    app.add_handler(CommandHandler("broadcast",    broadcast_cmd))
    app.add_handler(CommandHandler("stats",        stats_cmd))
    # media
    app.add_handler(MessageHandler(filters.PHOTO,          receive_photo))
    app.add_handler(MessageHandler(filters.Document.IMAGE, receive_document))
    # callbacks
    app.add_handler(CallbackQueryHandler(layout_cb, pattern="^layout_"))
    app.add_handler(CallbackQueryHandler(edit_cb,   pattern="^edit_"))

    logger.info("Bot started — %d slots, auto-build %ds, batch %ds",
                MAX_CONCURRENT, AUTO_IDLE, BATCH_IDLE)
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
