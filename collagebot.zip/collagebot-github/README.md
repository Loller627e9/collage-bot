# 📸 PGXC Collage Bot

A Telegram bot that turns screenshots into clean, professional collages — no commands needed. Send images and it auto-builds after a short idle period.

---

## Features

- **Auto-build** — sends a collage 2 seconds after you stop sending images
- **Batch mode** — queue many images, builds after 10 s of inactivity
- **4 layouts** — Auto, Horizontal, Wide, Vertical
- **Inline editing** — rebuild with different settings after delivery, no re-upload needed
- **Watermark** — add a custom text label to any collage
- **Crop UI** — strips phone status bars and navigation bars
- **Enhance** — sharpness, contrast, and brightness boost
- **Up to 20 images** per collage
- **Admin panel** — ban/unban users, broadcast messages, custom welcome message, live stats

---

## Quick Start

### 1. Prerequisites

- Python 3.10 or later
- A Telegram bot token from [@BotFather](https://t.me/BotFather)

### 2. Clone and install

```bash
git clone https://github.com/your-username/collagebot.git
cd collagebot
pip install -r requirements.txt
```

### 3. Configure

Copy the env template and fill in your values:

```bash
cp _env .env
```

Edit `.env`:

```env
BOT_TOKEN=your_bot_token_from_botfather
ADMIN_IDS=your_telegram_user_id
```

- Get your bot token from [@BotFather](https://t.me/BotFather)
- Find your Telegram user ID by messaging [@userinfobot](https://t.me/userinfobot)
- For multiple admins: `ADMIN_IDS=111111,222222`

### 4. Run

```bash
python bot.py
```

---

## Usage

Just send screenshots to the bot. After **2 seconds** of inactivity it automatically builds and delivers the collage as a full-quality JPEG document.

Use `/batch` to queue many images first — the collage then builds after **10 seconds** of inactivity.

After a collage is delivered, tap any button on the inline keyboard to rebuild it instantly with a different layout, compression level, watermark, crop, or enhance setting — without re-sending the images.

---

## Commands

### User commands

| Command | Description |
|---|---|
| `/start` | Show the welcome message |
| `/batch` | Enter batch queue mode (auto-builds after 10 s of inactivity) |
| `/layout` | Choose the collage grid layout |
| `/quality <1–95>` | Set JPEG output quality |
| `/watermark <text>` | Add or remove a watermark label |
| `/cropui` | Toggle removal of phone status and navigation bars |
| `/enhance` | Toggle sharpness and colour boost |
| `/undo` | Remove the last queued image |
| `/remove <n>` | Remove image at position n from the queue |
| `/count` | Show how many images are currently queued |
| `/status` | Show all current settings |
| `/clear` | Reset the queue and all settings |

### Admin commands

Admin commands are available only to users whose Telegram ID is in `ADMIN_IDS`. Type `/adminhelp` in the bot to see the full reference.

| Command | Description |
|---|---|
| `/adminhelp` | Show the full admin command reference |
| `/ban <id>` | Ban a user (or reply to their message) |
| `/unban <id>` | Unban a user |
| `/banlist` | List all banned users |
| `/broadcast <message>` | Send a message to all active sessions |
| `/setwelcome <text>` | Set a custom welcome message |
| `/resetwelcome` | Restore the default welcome message |
| `/stats` | Show session, queue, and ban counts |

---

## Layouts

| Layout | Description |
|---|---|
| **Auto** | Best-fit grid chosen automatically based on image count |
| **Horizontal** | Single row |
| **Wide** | Two rows |
| **Vertical** | Single column |

---

## File Structure

```
.
├── bot.py            # Main bot — commands, handlers, session management
├── collage.py        # Collage rendering engine (Pillow)
├── requirements.txt  # Python dependencies
├── _env              # Config template — copy to .env and fill in values
├── .gitignore        # Keeps secrets and temp files out of git
└── README.md         # This file

# Created at runtime (not committed):
# .env               — your secrets
# bot_state.json     — persisted banned users and custom welcome message
```

---

## Concurrency

The bot handles up to `MAX_CONCURRENT = 20` simultaneous collage builds using an `asyncio.Semaphore`. Extra requests wait in queue rather than being dropped. Collage rendering runs in a thread pool so the event loop stays non-blocking.

For sustained heavy load on a small VPS, lower `MAX_CONCURRENT` in `bot.py` to fit your hardware.

---

## Security

- **Never commit `.env` or `bot_state.json`** — both are in `.gitignore`
- `_env` is a safe placeholder template with no real credentials
- Rotate your bot token immediately if it was ever exposed publicly

---

## Dependencies

| Package | Purpose |
|---|---|
| `python-telegram-bot` | Telegram Bot API wrapper |
| `Pillow` | Image processing and collage rendering |
| `python-dotenv` | Load config from `.env` |
| `httpx` | HTTP client used by python-telegram-bot |

Install all at once:

```bash
pip install -r requirements.txt
```

---

## License

MIT — do whatever you want, just don't blame me if it breaks.
