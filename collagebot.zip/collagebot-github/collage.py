"""
collage.py — Smart collage builder (PGXC-style)

Rules:
  • Per-column width and per-row height from actual image dimensions (no white gaps)
  • Best-fit auto grid: picks rows×cols to match natural portrait screenshots
  • Minimal 3px gap, white background
  • Images letterboxed (never cropped, never stretched)
  • Subtle drop shadow per cell
  • Supports: auto, hstrip, wide, vstrip layouts
  • Optional: watermark text, enhance quality, crop phone UI (status bar)
"""

from PIL import Image, ImageDraw, ImageFilter, ImageEnhance, ImageFont
import math, os

GAP = 3
BG_COLOR = (245, 245, 245)
SHADOW_ALPHA = 60
SHADOW_BLUR = 3
SHADOW_OFFSET = 2
MAX_IMAGES = 20

def open_images(paths):
    return [Image.open(p).convert("RGB") for p in paths]

def fit_into(img, w, h):
    iw, ih = img.size
    scale = min(w / iw, h / ih, 1.0)
    nw, nh = max(1, int(iw * scale)), max(1, int(ih * scale))
    resized = img.resize((nw, nh), Image.LANCZOS)
    cell = Image.new("RGB", (w, h), BG_COLOR)
    cell.paste(resized, ((w - nw) // 2, (h - nh) // 2))
    return cell

def draw_shadow(canvas, x, y, w, h):
    shadow = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(shadow)
    draw.rectangle(
        [x + SHADOW_OFFSET, y + SHADOW_OFFSET,
         x + w + SHADOW_OFFSET - 1, y + h + SHADOW_OFFSET - 1],
        fill=(0, 0, 0, SHADOW_ALPHA)
    )
    blurred = shadow.filter(ImageFilter.GaussianBlur(SHADOW_BLUR))
    base = canvas.convert("RGBA")
    return Image.alpha_composite(base, blurred).convert("RGB")

def crop_phone_ui(img):
    w, h = img.size
    if h > w:
        return img.crop((0, int(h * 0.06), w, h - int(h * 0.08)))
    return img

def enhance_quality(img, sharpness=1.4, contrast=1.1, brightness=1.05):
    img = ImageEnhance.Sharpness(img).enhance(sharpness)
    img = ImageEnhance.Contrast(img).enhance(contrast)
    img = ImageEnhance.Brightness(img).enhance(brightness)
    return img

def add_watermark(canvas, text, opacity=80):
    overlay = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    W, H = canvas.size
    font_size = max(14, W // 40)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", font_size)
    except Exception:
        font = ImageFont.load_default()
    bbox = draw.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    margin = GAP * 4
    x, y = W - tw - margin, H - th - margin
    pad = 6
    draw.rounded_rectangle([x-pad, y-pad, x+tw+pad, y+th+pad], radius=4, fill=(0,0,0,120))
    draw.text((x, y), text, font=font, fill=(255, 255, 255, opacity))
    return Image.alpha_composite(canvas.convert("RGBA"), overlay).convert("RGB")

def best_grid(n):
    best, best_score = None, float("inf")
    for cols in range(1, n + 1):
        rows = math.ceil(n / cols)
        score = (cols * rows - n) * 2 + abs(cols / rows - 1.8)
        if score < best_score:
            best_score = score
            best = (cols, rows)
    return best

def build_grid_canvas(imgs, cols, rows):
    n = len(imgs)
    col_widths  = [0] * cols
    row_heights = [0] * rows
    for idx, img in enumerate(imgs):
        row, col = idx // cols, idx % cols
        iw, ih = img.size
        col_widths[col]  = max(col_widths[col],  iw)
        row_heights[row] = max(row_heights[row], ih)

    W = GAP + sum(col_widths)  + cols * GAP
    H = GAP + sum(row_heights) + rows * GAP

    col_x = [GAP + sum(col_widths[:c])  + c * GAP for c in range(cols)]
    row_y = [GAP + sum(row_heights[:r]) + r * GAP for r in range(rows)]

    canvas = Image.new("RGB", (W, H), BG_COLOR)
    for idx, img in enumerate(imgs):
        row, col = idx // cols, idx % cols
        cw, ch = col_widths[col], row_heights[row]
        x, y = col_x[col], row_y[row]
        canvas = draw_shadow(canvas, x, y, cw, ch)
        canvas.paste(fit_into(img, cw, ch), (x, y))
    return canvas

def layout_auto(imgs, *_):
    cols, rows = best_grid(len(imgs))
    return build_grid_canvas(imgs, cols, rows)

def layout_hstrip(imgs, *_):
    return build_grid_canvas(imgs, cols=len(imgs), rows=1)

def layout_wide(imgs, *_):
    cols = math.ceil(len(imgs) / 2)
    return build_grid_canvas(imgs, cols, 2)

def layout_vstrip(imgs, *_):
    return build_grid_canvas(imgs, cols=1, rows=len(imgs))

LAYOUTS = {"auto": layout_auto, "hstrip": layout_hstrip, "wide": layout_wide, "vstrip": layout_vstrip}

def make_collage(paths, output_path, layout="auto", quality=92,
                 watermark=None, enhance=False, crop_ui=False):
    if len(paths) > MAX_IMAGES:
        raise ValueError(f"Too many images: {len(paths)}. Max is {MAX_IMAGES}.")
    if len(paths) < 2:
        raise ValueError("Need at least 2 images.")
    imgs = open_images(paths)
    if crop_ui:
        imgs = [crop_phone_ui(i) for i in imgs]
    if enhance:
        imgs = [enhance_quality(i) for i in imgs]
    result = LAYOUTS.get(layout, layout_auto)(imgs)
    if watermark:
        result = add_watermark(result, watermark)
    result.save(output_path, "JPEG", quality=quality, optimize=True)
    return output_path
